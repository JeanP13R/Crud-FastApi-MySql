from sqlalchemy import String, Integer , Boolean, Column
from database import Base

class Ingreso(Base):
    __tablename__ = 'registrosdeingresos'

    idregistro = Column(Integer, primary_key=True, index=True)
    documentoingreso = Column(String(11))
    nombrepersona = Column(String(100))